#ifndef AST_hpp
#define AST_hpp

#include <stdio.h>
#include <string>
#include <vector>
#include <map>

using namespace std;

typedef vector<map<string, int> > Env;

class Expr {
public:
  // emit code and return the register number
  // that holds the value
  virtual int code(Env &env) = 0;
  
protected:
  static int nextRegister();
  static int registerNumber;
  static int lookup(Env &env, string name);
};

class Int : public Expr {
public:
  Int(int value);
  
  virtual int code(Env &env);
  
private:
  int value;
};

class Var : public Expr {
public:
  Var(string name);
  
  virtual int code(Env &env);
  
private:
  string name;
};

class Plus : public Expr {
public:
  Plus(Expr *left, Expr *right);
  
  virtual int code(Env &env);

private:
  Expr *left;
  Expr *right;
};

class Star : public Expr {
public:
  Star(Expr *left, Expr *right);
  
  virtual int code(Env &env);

private:
  Expr *left;
  Expr *right;
};

class Assign : public Expr {
public:
  Assign(string name, Expr *rhs);
  
  virtual int code(Env &env);

private:
  string name;
  Expr *rhs;
};

class Decl : public Expr {
public:
  Decl(string name);
  
  virtual int code(Env &env);

private:
  string name;
};

class Block : public Expr {
public:
  Block();
  
  void addExpr(Expr *e);
  
  virtual int code(Env &env);

private:
  vector<Expr*> exprs;
};


#endif /* AST_hpp */
