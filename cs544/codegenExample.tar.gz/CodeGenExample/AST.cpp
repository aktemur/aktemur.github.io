
#include "AST.hpp"
#include <iostream>

int Expr::registerNumber = 0;

int Expr::nextRegister() {
  return ++registerNumber;
}

int Expr::lookup(Env &env, string name) {
  auto it = env.rbegin();
  for (; it != env.rend(); ++it) {
    map<string, int> &table = *it;
    if (table.find(name) != table.end()) {
      return table[name];
    }
  }
  cerr << "Name " << name << " not found.\n";
  exit(-1);
}

Int::Int(int value) {
  this->value = value;
}

int Int::code(Env &env) {
  int regNum = nextRegister();
  cout << "%r" << regNum << " = add i32 " << value << ", 0\n";
  return regNum;
}

Var::Var(string name) {
  this->name = name;
}

int Var::code(Env &env) {
  int regNum = nextRegister();
  int address = lookup(env, name);
  cout << "%r" << regNum << " = load i32, i32* %r" << address << "\n";
  return regNum;
}

Plus::Plus(Expr *left, Expr *right) {
  this->left = left;
  this->right = right;
}

int Plus::code(Env &env) {
  int leftResult = left->code(env);
  int rightResult = right->code(env);
  int regNum = nextRegister();
  cout << "%r" << regNum << " = add i32 %r"
       << leftResult << ", %r" << rightResult << "\n";
  return regNum;
}

Star::Star(Expr *left, Expr *right) {
  this->left = left;
  this->right = right;
}

int Star::code(Env &env) {
  int leftResult = left->code(env);
  int rightResult = right->code(env);
  int regNum = nextRegister();
  cout << "%r" << regNum << " = mul i32 %r"
  << leftResult << ", %r" << rightResult << "\n";
  return regNum;
}

Assign::Assign(string name, Expr *rhs) {
  this->name = name;
  this->rhs = rhs;
}

int Assign::code(Env &env) {
  int rhsResult = rhs->code(env);
  int address = lookup(env, name);
  cout << "store i32 %r" << rhsResult << ", i32* %r" << address << "\n";
  return rhsResult;
}

Decl::Decl(string name) {
  this->name = name;
}

int Decl::code(Env &env) {
  int regNum = nextRegister();
  cout << "%r" << regNum << " = alloca i32\n";
  env.back()[name] = regNum;
  return regNum;
}

Block::Block() {
  // nothing
}

int Block::code(Env &env) {
  int result = 0;
  
  // create a new scope
  map<string, int> newTable;
  env.push_back(newTable);
  
  // emit code
  for (auto e: exprs) {
    result = e->code(env);
  }
  
  // exit the scope
  env.pop_back();
  
  return result;
}

void Block::addExpr(Expr *e) {
  exprs.push_back(e);
}
