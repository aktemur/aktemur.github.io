#include <iostream>
#include "AST.hpp"

using namespace std;

void emitHeader() {
  cout << "declare i32 @strcmp(i8*, i8*) \n";
  cout << "declare i32 @printf(i8*, ...) \n";
  cout << "declare void @abort() \n";
  cout << "declare i8* @malloc(i32) \n";
  cout << "\n";
  cout << "define i32 @Main_main() { \n";
  cout << "entry:\n";
}

void emitFooter(int resultRegister) {
  cout << "  ret i32 %r" << resultRegister << " \n";
  cout << "}\n\n";
  cout << "@main.printout.str = constant [25 x i8] ";
  cout << "c\"Main.main() returned %d\\0A\\00\", align 1 \n";
  cout << "\n";
  cout << "define i32 @main() {\n";
  cout << "entry:\n";
  cout << "  %tpm.0 = call i32 @Main_main(  )\n";
  cout << "  %tpm.1 = getelementptr [25 x i8], [25 x i8]* @main.printout.str, i32 0, i32 0\n";
  cout << "  %tpm.2 = call i32(i8*, ... ) @printf( i8* %tpm.1, i32 %tpm.0 ) \n";
  cout << "  ret i32 0 \n";
  cout << "}\n";
}

Expr* exp1() {
  return new Int(42);
}

Expr* exp2() {
  return new Plus(new Int(42),
                  new Star(new Int(5), new Int(6)));
}

Expr* exp3() {
  Expr *exp = new Block();
  ((Block*)exp)->addExpr(new Decl("x"));
  ((Block*)exp)->addExpr(new Assign("x", new Int(42)));
  ((Block*)exp)->addExpr(new Plus(new Int(6), new Var("x")));
  return exp;
}

Expr* exp4() {
  Block *exp = new Block();
  exp->addExpr(new Decl("y"));
  exp->addExpr(new Assign("y", new Int(42)));
  Block *innerBlock = new Block();
  innerBlock->addExpr(new Decl("x"));
  innerBlock->addExpr(new Assign("x", new Int(5)));
  exp->addExpr(innerBlock);
  exp->addExpr(new Assign("y", new Star(new Var("x"),
                                        new Int(2))));
  return exp;
}

Expr* exp5() {
  Block *exp = new Block();
  exp->addExpr(new Decl("y"));
  exp->addExpr(new Assign("y", new Int(42)));
  Block *innerBlock = new Block();
  innerBlock->addExpr(new Decl("y"));
  innerBlock->addExpr(new Assign("y", new Int(5)));
  exp->addExpr(innerBlock);
  exp->addExpr(new Assign("y", new Star(new Var("y"),
                                        new Int(2))));
  return exp;
}


int main(int argc, const char * argv[]) {
  int result = -1;
  Expr *exp;
  vector<map<string,int> > env;
  map<string, int> newTable;
  env.push_back(newTable);
  
  emitHeader();
  
  exp = exp3();
  result = exp->code(env);
  emitFooter(result);
  return 0;
}
