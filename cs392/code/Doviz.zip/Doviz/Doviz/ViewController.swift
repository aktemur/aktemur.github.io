//
//  ViewController.swift
//  Doviz
//
//  Created by Baris Aktemur on 04/11/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
  var json: [[String: String]]!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    fetchJSONData()
  }

  func fetchJSONData() {
    let url = "http://api.piyasa.com/json/?kaynak=doviz_guncel_serb"
    if let nsurl = NSURL(string: url) {
      if let nsdata = NSData(contentsOfURL: nsurl) {
        json = NSJSONSerialization.JSONObjectWithData(nsdata, options: NSJSONReadingOptions.AllowFragments, error: nil) as [[String: String]]
      }
    }
  }
  
  @IBAction func refresh() {
    fetchJSONData()
    tableView.reloadData()
    refreshControl?.endRefreshing()
  }
  
  override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return json.count
  }
  
  override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("DovizCell") as UITableViewCell
    
    let dovizInfo = json[indexPath.item]
    cell.textLabel.text = dovizInfo["foex"]
    cell.detailTextLabel?.text = dovizInfo["buy"]
    
    return cell
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

