//
//  University.swift
//  FacultyFacebook
//
//  Created by Baris Aktemur on 18/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

class University {
  var departments = [Department]()
  
  func addDepartment(department: Department) {
    departments.append(department)
  }
}