//
//  ViewController.swift
//  FacultyFacebookWithCollectionView
//
//  Created by Baris Aktemur on 05/11/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UICollectionViewController {
  let university = OzyeginUniversity()
  
  override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
    return university.departments.count
  }
  
  override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return university.departments[section].facultyMembers.count
  }
  
  override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCellWithReuseIdentifier("FacultyMemberCell", forIndexPath: indexPath) as UICollectionViewCell
    
    let member = university.departments[indexPath.section].facultyMembers[indexPath.item]
    let url = "http://annualreport.ozyegin.edu.tr/images/profile/" + member.userName + ".jpg"
    if let nsurl = NSURL(string: url) {
      if let nsdata = NSData(contentsOfURL: nsurl) {
        if let image = UIImage(data: nsdata) {
          let imageView = cell.viewWithTag(99) as UIImageView
          imageView.image = image
        }
      }
    }
    
    return cell
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

