//
//  ViewController.swift
//  SegueExperiment
//
//  Created by Baris Aktemur on 30/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
  @IBOutlet weak var textField: UITextField!
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }

  override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    let destinationVC = segue.destinationViewController as SecondViewController
    if let segueID = segue.identifier {
      if segueID == "SendSegue" {
        destinationVC.info = textField.text
      } else {
        destinationVC.info = "42"
      }
    }
  }
  
}

