//
//  SecondViewController.swift
//  SegueExperiment
//
//  Created by Baris Aktemur on 31/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
  var info: String!
  
  @IBOutlet weak var infoLabel: UILabel!
  
  @IBAction func backButtonTapped() {
    dismissViewControllerAnimated(true, completion: nil)
  }
  
  override func viewDidLoad() {
    infoLabel.text = info
  }
}
