//
//  ViewController.swift
//  UserDefaultsExperiment
//
//  Created by Baris Aktemur on 17/11/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

  var items: [String]!
  
  @IBOutlet weak var textField: UITextField!
  @IBOutlet weak var tableView: UITableView!
  
  @IBAction func addButtonTapped() {
    if textField.text != "" {
      items.append(textField.text)
      let userDefaults = NSUserDefaults.standardUserDefaults()
      userDefaults.setObject(items, forKey: "items")
      tableView.reloadData()
      textField.text = ""
    }
  }
  
  func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return items.count
  }
  
  func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("TableCell") as UITableViewCell
    
    cell.textLabel.text = items[indexPath.item]
    
    return cell
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    let userDefaults = NSUserDefaults.standardUserDefaults()
    if let defaultItems = userDefaults.arrayForKey("items") {
      items = defaultItems as [String]
    } else {
      items = [String]()
      userDefaults.setObject(items, forKey: "items")
    }
  }
}

