//
//  ViewController.swift
//  LocationExperiment
//
//  Created by Gün Makinabakan on 17/12/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

  // Best practice: Define the location manager instance as a Singleton
  let locationManager = CLLocationManager()
  
  @IBOutlet weak var mapView: MKMapView!

  override func viewDidLoad() {
    super.viewDidLoad()
    locationManager.desiredAccuracy = kCLLocationAccuracyBest
    // Warning: accuracy affects battery life!
    
    locationManager.delegate = self
    
    /* Experiment 1: Getting periodic location updates

    // distanceFilter: Specifies the minimum update distance in meters. 
    //   Client will not be notified of movements of less
    //   than the stated value, unless the accuracy has improved.
    locationManager.distanceFilter = 10 // meters
    
    // Request location permission
    // locationManager.requestWhenInUseAuthorization()
    locationManager.requestAlwaysAuthorization()
    
    locationManager.startUpdatingLocation()
    // Also check other methods whose name starts with "start"
    */
    
    /* Experiment 2: Region monitoring
    */
    locationManager.requestAlwaysAuthorization()
    let region = CLCircularRegion(center: CLLocationCoordinate2DMake(20.1, 20.1), radius: 100, identifier: "Region 1")
    locationManager.startMonitoringForRegion(region)
  }
  
  // Invoked when new locations are available.
  // `locations` is an array of CLLocation objects in chronological order.
  func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
    NSLog("Updated location %@", locationManager.location)
  }

  // Invoked when the user entered the specified region
  func locationManager(manager: CLLocationManager!, didEnterRegion region: CLRegion!) {
    NSLog("Entered %@", region)
  }
  
  // Invoked when the user exited the specified region
  func locationManager(manager: CLLocationManager!, didExitRegion region: CLRegion!) {
    NSLog("Exited %@", region)
  }

  override func viewDidAppear(animated: Bool) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(3 * NSEC_PER_SEC)), dispatch_get_main_queue()) {
      let span = MKCoordinateSpanMake(0.01, 0.01)
      // Also set user location to the custom location lat: 41.028794, long: 29.259657
      // in simulator's debug menu.
      let region = MKCoordinateRegionMake(CLLocationCoordinate2DMake(41.028794, 29.259657), span)
      self.mapView.setRegion(region, animated: true)
    }
    
    let annotation = MKPointAnnotation()
    annotation.setCoordinate(CLLocationCoordinate2DMake(41.028794, 29.259657))
    annotation.title = "Özyeğin Üniversitesi"
    annotation.subtitle = "Bilim yuvası"
    mapView.addAnnotation(annotation)
  }

  func mapView(mapView: MKMapView!, didUpdateUserLocation userLocation: MKUserLocation!) {
    let span = MKCoordinateSpanMake(0.01, 0.01)
    let region = MKCoordinateRegionMake(self.mapView.userLocation.location.coordinate, span)
    self.mapView.setRegion(region, animated: true)
  }
  
  func mapViewDidFinishLoadingMap(mapView: MKMapView!) {
    mapView.showsUserLocation = true
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
}

