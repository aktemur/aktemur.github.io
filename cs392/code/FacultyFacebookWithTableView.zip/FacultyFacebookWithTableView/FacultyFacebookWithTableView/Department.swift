//
//  Department.swift
//  FacultyFacebook
//
//  Created by Baris Aktemur on 18/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

class Department {
  var facultyMembers = [FacultyMember]()
  let fullName: String
  let shortName: String
  
  init(fullName: String, shortName: String) {
    self.fullName = fullName
    self.shortName = shortName
  }
  
  func addMember(member: FacultyMember) {
    facultyMembers.append(member)
  }
}