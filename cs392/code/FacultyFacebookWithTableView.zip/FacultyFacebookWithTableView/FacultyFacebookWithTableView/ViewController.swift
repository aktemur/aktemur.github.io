//
//  ViewController.swift
//  FacultyFacebookWithTableView
//
//  Created by Baris Aktemur on 19/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
  let university = OzyeginUniversity()
  
  @IBOutlet weak var facultyMemberImage: UIImageView!
  
  func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return university.departments.count
  }
  
  func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return university.departments[section].facultyMembers.count
  }
  
  func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let deptIndex = indexPath.section
    let memberIndex = indexPath.item

    let cell = tableView.dequeueReusableCellWithIdentifier("FacultyNameCell") as UITableViewCell
    let member = university.departments[deptIndex].facultyMembers[memberIndex]
    cell.textLabel!.text = member.name + " " + member.lastName
    
    return cell
  }
  
  func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
    return university.departments[section].fullName
  }
  
  func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
    let deptIndex = indexPath.section
    let memberIndex = indexPath.item
    
    let member = university.departments[deptIndex].facultyMembers[memberIndex]
    let url = "http://annualreport.ozyegin.edu.tr/images/profile/" + member.userName + ".jpg"
    
    facultyMemberImage.image = UIImage(data: NSData(contentsOfURL: NSURL(string: url)))
    
    let cell = tableView.cellForRowAtIndexPath(indexPath)
    cell?.selected = false
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

