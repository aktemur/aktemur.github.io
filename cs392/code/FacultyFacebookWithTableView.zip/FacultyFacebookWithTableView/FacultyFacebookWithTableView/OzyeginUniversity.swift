//
//  OzyeginUniversity.swift
//  FacultyFacebook
//
//  Created by Baris Aktemur on 18/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

class OzyeginUniversity: University {
  override init() {
    super.init()
    populateCS()
    populateEE()
    populateIE()
  }

  // These are the faculty members for whom I know the URL to their image
  
  private func populateCS() {
    let dept = Department(fullName: "Computer Science", shortName: "CS")
    dept.addMember(FacultyMember(name: "Reha", lastName: "Civanlar", userName:"rehac"))
    dept.addMember(FacultyMember(name: "Tanju", lastName:"Erdem", userName:"tanjue"))
    dept.addMember(FacultyMember(name: "Ismail", lastName:"Ari", userName:"ismaila"))
    dept.addMember(FacultyMember(name: "Baris", lastName:"Aktemur", userName:"barisa"))
    dept.addMember(FacultyMember(name: "Hasan", lastName:"Sozer", userName:"hasans"))
    dept.addMember(FacultyMember(name: "Erhan", lastName:"Oztop", userName:"erhano"))
    dept.addMember(FacultyMember(name: "Murat", lastName:"Sensoy", userName:"muratsen"))
    self.addDepartment(dept)
  }
  
  private func populateEE() {
    let dept = Department(fullName:"Electrical & Electonics Engineering", shortName: "EE")
    dept.addMember(FacultyMember(name: "Oguz", lastName:"Sunay", userName: "oguzs"))
    dept.addMember(FacultyMember(name: "Murat", lastName:"Uysal", userName: "muratu"))
    dept.addMember(FacultyMember(name: "Cenk", lastName:"Demiroglu", userName: "cenkd"))
    dept.addMember(FacultyMember(name: "Ali Ozer", lastName:"Ercan", userName: "alie"))
    dept.addMember(FacultyMember(name: "Fatih", lastName:"Ugurdag", userName: "fatihu"))
    dept.addMember(FacultyMember(name: "Goksenin", lastName:"Yaralioglu", userName: "gokseniny"))
    self.addDepartment(dept)
  }
  
  private func populateIE() {
    let dept = Department(fullName: "Industrial Engineering", shortName: "IE")
    dept.addMember(FacultyMember(name: "Meltem", lastName:"Denizel", userName: "meltemd"))
    dept.addMember(FacultyMember(name: "Ekrem", lastName:"Duman", userName: "ekremd"))
    dept.addMember(FacultyMember(name: "Orsan", lastName:"Ozener", userName: "okano"))
    self.addDepartment(dept)
  }
}