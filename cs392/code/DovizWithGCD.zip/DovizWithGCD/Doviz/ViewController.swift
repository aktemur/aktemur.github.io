//
//  ViewController.swift
//  Doviz
//
//  Created by Baris Aktemur on 04/11/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UITableViewController, UISearchBarDelegate {
  var json: [[String: String]]!
  var entries = [[String:String]]()
  @IBOutlet weak var searchBar: UISearchBar!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    json = []
  }

  func searchBar(searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
    self.sortEntries()
    tableView.reloadData()
  }

  private func sortEntries() {
    let byName = searchBar.selectedScopeButtonIndex == 0
    if byName {
      entries.sort({ $0["foex"] < $1["foex"]})
    } else {
      entries.sort({ $0["buy"] < $1["buy"]})
    }
  }
  
  func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
    filterEntries()
    tableView.reloadData()
  }
  
  private func filterEntries() {
    let searchText = searchBar.text
    if searchText == nil || searchText == "" {
      entries = json
    } else {
      entries = json.filter({
        $0["foex"]!.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch) != nil
      })
    }
    sortEntries()
  }
  
  func fetchJSONData() {
    let url = "http://api.piyasa.com/json/?kaynak=doviz_guncel_serb"
    if let nsurl = NSURL(string: url) {
      if let nsdata = NSData(contentsOfURL: nsurl) {
        sleep(2) // to simulate network delay
        json = NSJSONSerialization.JSONObjectWithData(nsdata, options: NSJSONReadingOptions.AllowFragments, error: nil) as [[String: String]]
      }
    }
  }
  
  @IBAction func refresh() {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_BACKGROUND, 0), {
      self.fetchJSONData()
      self.entries = self.json
      self.filterEntries()
      dispatch_async(dispatch_get_main_queue(), {
        self.tableView.reloadData()
        self.refreshControl?.endRefreshing()
      })
    })
  }
  
  override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return entries.count
  }
  
  override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("DovizCell") as UITableViewCell
    
    let dovizInfo = entries[indexPath.item]
    cell.textLabel.text = dovizInfo["foex"]
    cell.detailTextLabel?.text = dovizInfo["buy"]
    
    return cell
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

