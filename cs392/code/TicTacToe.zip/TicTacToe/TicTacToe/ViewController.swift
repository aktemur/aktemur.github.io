//
//  ViewController.swift
//  TicTacToe
//
//  Created by Baris Aktemur on 06/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  var grid = TicTacToeGrid()
  
  @IBOutlet weak var infoLabel: UILabel!

  @IBOutlet var cells: [UIButton]!
  
  @IBAction func cellButtonTapped(sender: UIButton) {
    let row = sender.tag / GRID_SIZE
    let col = sender.tag % GRID_SIZE
    grid.markCellAt(row, col: col)
    refreshUI()
  }
  
  private func refreshUI() {
    for cell in cells {
      cell.enabled = true
      let row = cell.tag / GRID_SIZE
      let col = cell.tag % GRID_SIZE
      let state = grid.cells[row][col]
      switch state {
      case CellState.Blank:
        cell.setTitle(" ", forState: .Normal)
      case CellState.PlayerX:
        cell.setTitle("X", forState: .Normal)
      case CellState.PlayerO:
        cell.setTitle("O", forState: .Normal)
      }
    }
    
    switch grid.gameState {
    case GameState.InProgress:
      infoLabel.text = "Current player: " + (grid.isPlayerXsTurn ? "X" : "O")
    case GameState.Tie:
      infoLabel.text = "Game tied!"
    case GameState.WinByX:
      infoLabel.text = "Player X wins!!"
    case GameState.WinByO:
      infoLabel.text = "Player O wins!!"
    }
    
    if grid.gameState != GameState.InProgress {
      for cell in cells {
        cell.enabled = false
      }
    }
  }
  
  @IBAction func resetButtonTapped() {
    grid = TicTacToeGrid()
    refreshUI()
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    refreshUI()
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

