//
//  TicTacToeGrid.swift
//  TicTacToe
//
//  Created by Baris Aktemur on 05/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

enum CellState {
  case Blank, PlayerX, PlayerO
}

enum GameState {
  case InProgress, WinByX, WinByO, Tie
}

let GRID_SIZE = 3

class TicTacToeGrid {
  var cells: [[CellState]]
  var isPlayerXsTurn: Bool
  var gameState = GameState.InProgress
  
  init() {
    let cellRow = [CellState](count: GRID_SIZE, repeatedValue: .Blank)
    cells = [[CellState]](count: GRID_SIZE, repeatedValue: cellRow)
    isPlayerXsTurn = true
  }
  
  func markCellAt(row: Int, col: Int) {
    if row >= 0 && col >= 0 && row < GRID_SIZE && col < GRID_SIZE {
      if cells[row][col] == .Blank {
        if isPlayerXsTurn {
          cells[row][col] = .PlayerX
        } else {
          cells[row][col] = .PlayerO
        }
        updateGameStateFor(row, col: col)
        switchPlayer()
      }
    }
  }
  
  private func updateGameStateFor(row: Int, col: Int) {
    // Check if all the elements on this row are the same
    var isWinnerRow = true
    for j in 0..<GRID_SIZE {
      if cells[row][j] != cells[row][col] {
        isWinnerRow = false
      }
    }
    if isWinnerRow {
      gameState = cellStateToGameState(cells[row][col])
      return
    }
    
    // Check if all the elements on this col are the same
    var isWinnerCol = true
    for j in 0..<GRID_SIZE {
      if cells[j][col] != cells[row][col] {
        isWinnerCol = false
      }
    }
    if isWinnerCol {
      gameState = cellStateToGameState(cells[row][col])
      return
    }
    
    // Diagonals
    if row == col { // this cell is on the diagonal
      var isWinnerDiagonal = true
      for i in 0..<GRID_SIZE {
        if cells[i][i] != cells[row][col] {
          isWinnerDiagonal = false
        }
      }
      if isWinnerDiagonal {
        gameState = cellStateToGameState(cells[row][col])
        return
      }
    }
    
    if row == GRID_SIZE - 1 - col { // this cell is on the reverse diagonal
      var isWinnerDiagonal = true
      for i in 0..<GRID_SIZE {
        if cells[i][GRID_SIZE-1-i] != cells[row][col] {
          isWinnerDiagonal = false
        }
      }
      if isWinnerDiagonal {
        gameState = cellStateToGameState(cells[row][col])
        return
      }
    }
    
    // Check tie condition
    var areAllCellsMarked = true
    for cellRow in cells {
      for cell in cellRow {
        if cell == .Blank {
          areAllCellsMarked = false
        }
      }
    }
    
    if areAllCellsMarked {
      gameState = GameState.Tie
    } else {
      gameState = GameState.InProgress
    }
  }
  
  private func cellStateToGameState(state: CellState) -> GameState {
    if state == .PlayerX {
      return .WinByX
    } else if state == .PlayerO {
      return .WinByO
    } else {
      return .InProgress
    }
  }
  
  private func switchPlayer() {
    isPlayerXsTurn = !isPlayerXsTurn
  }
}