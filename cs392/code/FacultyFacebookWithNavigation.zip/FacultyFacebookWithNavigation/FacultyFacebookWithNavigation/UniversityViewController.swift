//
//  UniversityViewController.swift
//  FacultyFacebookWithNavigation
//
//  Created by Baris Aktemur on 31/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class UniversityViewController: UITableViewController {
  let university = OzyeginUniversity()
  
  override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return university.departments.count
  }
  
  override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("DepartmentCell") as UITableViewCell
    let department = university.departments[indexPath.item]
    cell.textLabel.text = department.shortName
    cell.detailTextLabel?.text = department.fullName
    
    return cell
  }
  
  override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    let cell = sender as UITableViewCell
    let indexPath = tableView.indexPathForCell(cell)
    let department = university.departments[indexPath!.item]
    let departmentVC = segue.destinationViewController as DepartmentViewController
    departmentVC.department = department
  }
}
