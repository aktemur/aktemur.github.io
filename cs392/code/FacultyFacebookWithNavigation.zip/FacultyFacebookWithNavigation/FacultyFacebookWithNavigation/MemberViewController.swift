//
//  MemberViewController.swift
//  FacultyFacebookWithNavigation
//
//  Created by Baris Aktemur on 31/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class MemberViewController: UIViewController {
  var member: FacultyMember!
  
  @IBOutlet weak var nameLabel: UILabel!
  
  @IBOutlet weak var imageView: UIImageView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    nameLabel.text = member.name + " " + member.lastName
    
    let url = "http://annualreport.ozyegin.edu.tr/images/profile/" + member.userName + ".jpg"
    if let nsurl = NSURL(string: url) {
      if let nsdata = NSData(contentsOfURL: nsurl) {
        imageView.image = UIImage(data: nsdata)
      }
    }
  }
  
}
