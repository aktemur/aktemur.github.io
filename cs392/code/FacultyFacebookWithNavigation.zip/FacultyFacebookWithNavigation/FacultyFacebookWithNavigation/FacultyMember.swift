//
//  FacultyMember.swift
//  FacultyFacebook
//
//  Created by Baris Aktemur on 18/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

class FacultyMember {
  let name: String
  let lastName: String
  let userName: String
  
  init(name: String, lastName: String, userName: String) {
    self.name = name
    self.lastName = lastName
    self.userName = userName
  }
}
