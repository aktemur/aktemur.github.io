//
//  DepartmentViewController.swift
//  FacultyFacebookWithNavigation
//
//  Created by Baris Aktemur on 31/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class DepartmentViewController: UITableViewController {
  var department: Department!
  
  override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return department.facultyMembers.count
  }
  
  override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCellWithIdentifier("FacultyNameCell") as UITableViewCell
    let member = department.facultyMembers[indexPath.item]
    cell.textLabel.text = member.name + " " + member.lastName
    
    return cell
  }
  
  override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    let cell = sender as UITableViewCell
    let indexPath = tableView.indexPathForCell(cell)
    let member = department.facultyMembers[indexPath!.item]
    let memberVC = segue.destinationViewController as MemberViewController
    memberVC.member = member
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.title = department.shortName
  }
}
