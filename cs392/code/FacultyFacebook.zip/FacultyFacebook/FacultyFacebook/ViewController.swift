//
//  ViewController.swift
//  FacultyFacebook
//
//  Created by Baris Aktemur on 18/10/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
  let ozyegin = OzyeginUniversity()
  
  @IBOutlet weak var facultyMemberImage: UIImageView!
  
  func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
    return 2
  }
  
  func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    if component == 0 { // departments
      return ozyegin.departments.count
    } else { // members
      let deptIndex = pickerView.selectedRowInComponent(0)
      let dept = ozyegin.departments[deptIndex]
      return dept.facultyMembers.count
    }
  }
  
  func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
    if component == 0 { // departments
      return ozyegin.departments[row].shortName
    } else { // members
      let dept = ozyegin.departments[pickerView.selectedRowInComponent(0)]
      let person = dept.facultyMembers[row]
      return person.name + " " + person.lastName
    }
  }
  
  func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
    if component == 0 { // new department selected
      pickerView.reloadAllComponents()
    }
    let person = ozyegin.departments[pickerView.selectedRowInComponent(0)].facultyMembers[pickerView.selectedRowInComponent(1)]
    let username = person.userName
    let url = "http://annualreport.ozyegin.edu.tr/images/profile/" + username + ".jpg"
    facultyMemberImage.image = UIImage(data: NSData(contentsOfURL: NSURL(string: url)))
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

