//
//  ViewController.swift
//  PicnicAnimation
//
//  Created by Gün Makinabakan on 03/12/14.
//  Copyright (c) 2014 Gün Makinabakan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var bottomDoor: UIImageView!
  
  @IBOutlet weak var topDoor: UIImageView!
  @IBOutlet weak var plate: UIImageView!
  @IBOutlet weak var bug: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  override func viewDidAppear(animated: Bool) {
    plate.alpha = 0
    
    UIView.animateWithDuration(2, animations: {
      self.bottomDoor.frame.origin.y = UIScreen.mainScreen().bounds.size.height
      self.topDoor.frame.origin.y = (0 - self.topDoor.frame.size.height)
    }) { (Bool) -> Void in
      self.animateBug()
    }
    
    UIView.animateWithDuration(2, delay: 1, options: nil, animations: {
      self.plate.alpha = 1
    }) { (Bool) -> Void in
      
    }
  }

  func animateBug(){
    /*UIView.animateWithDuration(3, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: { () -> Void in
      self.bug.frame.origin.y += 250
      self.bug.frame.origin.x += 150
    }) { (Bool) -> Void in
      
    }*/
    
    UIView.animateWithDuration(2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 3, options: nil, animations: {
      self.bug.frame.origin.y += 250
      self.bug.frame.origin.x += 150
    }) { (Bool) -> Void in
      
    }
  }
}

