//
//  ViewController.swift
//  SimpleDie
//
//  Created by Baris Aktemur on 30/09/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  let die = Die(numFaces: 10)

  @IBOutlet weak var dieLabel: UILabel!
  
  @IBAction func rollButtonTapped() {
    die.roll()
    refreshUI()
  }
  
  func refreshUI() {
    dieLabel.text = die.faceSymbol()
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    refreshUI()
  }
}

