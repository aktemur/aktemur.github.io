//
//  Die.swift
//  SimpleDie
//
//  Created by Baris Aktemur on 30/09/14.
//  Copyright (c) 2014 Ozyegin University. All rights reserved.
//

import Foundation

class Die {
  let numFaces: Int
  var faceValue = 0
  
  init(numFaces: Int) {
    self.numFaces = numFaces
  }
  
  convenience init() {
    self.init(numFaces: 6)
  }
  
  func roll() {
    self.faceValue = random() % numFaces
  }
  
  func faceSymbol() -> String {
    let symbols = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
    if (numFaces == symbols.count) {
      return symbols[faceValue]
    } else {
      return faceValue.description
    }
  }
}