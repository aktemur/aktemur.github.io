module Fun

open Absyn

(* Environment operations *)
type 'v env = (string * 'v) list

let rec lookup env x =
    match env with 
    | []        -> failwith (x + " not found")
    | (y, v)::r -> if x=y then v else lookup r x;;

(* A runtime value is an integer, boolean, or a function closure *)
type value = 
  | Int of int
  | Closure of string * expr * value env (* (x, fBody, fDeclEnv *)
  | Bool of bool
  | Rec of string * expr * value env  (* f, eRhs, declEnv *)
  
let rec eval (e : expr) (env : value env) : value =
    match e with 
    | CstI i -> Int(i)
    | CstB b -> Bool(b)
    | Var x  ->
      match lookup env x with
      | Rec(x, eRhs, eEnv) ->
         eval eRhs ((x,Rec(x, eRhs, eEnv))::eEnv)
      | v -> v
    | Prim(ope, e1, e2) -> 
      match eval e1 env, eval e2 env with
      | Int(i1), Int(i2) -> 
         match ope with
         | "*" -> Int(i1 * i2)
         | "+" -> Int(i1 + i2)
         | "-" -> Int(i1 - i2)
         | "/" -> Int(i1 / i2)
         | "%" -> Int(i1 % i2)
         | "=" -> Bool(i1 = i2)
         | "<>"-> Bool(not(i1 = i2))
         | ">="-> Bool(i1 >= i2)
         | "<="-> Bool(i1 <= i2)
         | ">" -> Bool(i1 >  i2)
         | "<" -> Bool(i1 <  i2)
         | _   -> failwith ("unknown primitive " + ope)
      | _ -> failwith ("Prim operands must be Int's.")
    | If(e1, e2, e3) ->
      match eval e1 env with
      | Bool(b) -> if b then eval e2 env
                   else eval e3 env
      | _ -> failwith ("Condition of 'if' not a bool.")
    | Fun(x, t1, e, t2) -> Closure(x, e, env)
    | Let(x, eRhs, letBody) -> 
      let xVal = eval eRhs env
      let bodyEnv = (x, xVal) :: env
      eval letBody bodyEnv
    | Call(e1, e2) ->
      match eval e1 env with 
      | Closure(x, ebody, fEnv) ->
         let v2 = eval e2 env
         eval ebody ((x,v2)::fEnv)
      | _ -> failwith "LHS of Call not a closure"
    | LetRec(x, eRhs, letBody) -> 
      let xVal = eval eRhs ((x, Rec(x, eRhs, env))::env)
      let bodyEnv = (x, xVal) :: env
      eval letBody bodyEnv

(* Type checking *)
let rec typ (e : expr) (env : typ env) : typ =
    match e with 
    | CstI i -> TypI
    | CstB b -> TypB
    | Var x  -> lookup env x
    | Prim(ope, e1, e2) -> 
      match typ e1 env, typ e2 env with
      | TypI, TypI -> 
         match ope with
         | "*" -> TypI
         | "+" -> TypI
         | "-" -> TypI
         | "/" -> TypI
         | "%" -> TypI
         | "=" -> TypB
         | "<>"-> TypB
         | ">="-> TypB
         | "<="-> TypB
         | ">" -> TypB
         | "<" -> TypB
         | _   -> failwith ("unknown primitive " + ope)
      | _ -> failwith ("Prim operands must be Int's.")
    | If(e1, e2, e3) ->
      match typ e1 env, typ e2 env, typ e3 env with
      | TypB, t2, t3 -> if t2 = t3 then t2
                        else failwith ("Branches of 'if' must have the same type.")
      | _ -> failwith ("Condition of 'if' not a bool.")
    | Fun(x, t1, e, t2) ->
        let tBody = typ e ((x,t1)::env)
        if tBody = t2 then TypF(t1,t2)
        else failwith "Function body does not have the declared type."
    | Let(x, eRhs, letBody) -> 
      let xType = typ eRhs env
      let bodyEnv = (x, xType) :: env
      typ letBody bodyEnv
    | Call(e1, e2) ->
      match typ e1 env, typ e2 env with 
      | TypF(t1,t2), t3 ->
         if t1 = t3 then t2
         else failwith "Function's input type not the same as argument type."
      | _ -> failwith "LHS of Call is not a function."
    | LetRec(f, Fun(x, t1, fBody, t2), letRecBody) -> 
      let fType = typ (Fun(x, t1, fBody, t2)) ((f, TypF(t1,t2))::env)
      let bodyEnv = (f, fType) :: env
      typ letRecBody bodyEnv
    | LetRec(f, _, _) -> failwith "Only functions can be declared as recursive."

(* Example programs *)
let factExp = Parse.fromString @"let rec fact = fun n:int :int -> if n = 1 then 1
                                                              else n * fact (n-1)
                                 in fact 5 end";;

let higherOrder1 = Parse.fromString @"let add = fun x:int :(int->int) -> fun y:int :int -> x + y
                                      in add 17 end"

let higherOrder2 = Parse.fromString @"let add = fun x:int :(int->int) -> fun y:int :int -> x + y
                                      in let add17 = add 17
                                         in add17 25 end end"

let higherOrder3 = Parse.fromString @"let g = fun f:int->int :int -> f 12
                                      in g (fun x:int :int -> x * 2) end"

(* Evaluate in empty environment: program must have no free variables: *)
let run e = eval e [];;

(* Type-check in empty environment: program must have no free variables: *)
let typeCheck e = typ e [];;

