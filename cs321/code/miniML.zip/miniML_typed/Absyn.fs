(* Fun/Absyn.fs * Abstract syntax for micro-ML, a functional language *)

module Absyn

type typ =
  | TypI              (* int  *)
  | TypB              (* bool *)
  | TypF of typ * typ (* Function type *)
  
type expr = 
  | CstI of int
  | CstB of bool
  | Var of string
  | Let of string * expr * expr
  | LetRec of string * expr * expr
  | Fun of string * typ * expr * typ
  | Prim of string * expr * expr
  | If of expr * expr * expr
  | Call of expr * expr

