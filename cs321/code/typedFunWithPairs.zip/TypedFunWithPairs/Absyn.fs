(* Fun/Absyn.fs * Abstract syntax for micro-ML, a functional language *)

module Absyn

type typ =
  | TypI              (* int  *)
  | TypB              (* bool *)
  | TypF of typ * typ (* Function type *)
  | TypP of typ * typ (* Pair type *)

type tyexpr = 
  | CstI of int
  | CstB of bool
  | Var of string
  | Let of string * tyexpr * tyexpr
  | Prim of string * tyexpr * tyexpr
  | If of tyexpr * tyexpr * tyexpr
  | Letfun of string * string * typ * tyexpr * typ * tyexpr
  | Call of tyexpr * tyexpr
  | Pair of tyexpr * tyexpr
  | MatchPair of tyexpr * string * string * tyexpr
