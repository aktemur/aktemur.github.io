module GraderLib

let test1Arg f1 f2 x1 () = (f1 x1 = f2 x1)
let test2Arg f1 f2 x1 x2 () = (f1 x1 x2 = f2 x1 x2)
let test3Arg f1 f2 x1 x2 x3 () = (f1 x1 x2 x3 = f2 x1 x2 x3)
let test4Arg f1 f2 x1 x2 x3 x4 () = (f1 x1 x2 x3 x4 = f2 x1 x2 x3 x4)
let test5Arg f1 f2 x1 x2 x3 x4 x5 () = (f1 x1 x2 x3 x4 x5 = f2 x1 x2 x3 x4 x5)

