module Grader
open TestCases

let runCases cases =
    let rec aux cases totalScore accumulatedScore =
        match cases with
          [] -> (accumulatedScore, totalScore)
        | (w,v,t)::cs -> let b = try v() with _ -> false
                         printf "[%2d|%s] %s\n" w (if b then "pass" else "FAIL") t
                         aux cs (totalScore+w) (accumulatedScore + if b then w else 0)
    aux cases 0 0

let main () =
    let granted,total = runCases testCases
    printf "Score: [%d/%d]\n" granted total
    
let _ = main()
