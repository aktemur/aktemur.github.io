module TestCases
open GraderLib

(* NOTE: This file contains test cases to be used for
   grading. The file given to you is INCOMPLETE.
   A much more extensive test suite will be used for
   grading. You are highly recommended to add new test
   cases to improve the coverage of the test suite,
   and hence your confidence on the correctness of your
   functions.
*)

(* Each test case is in this form:
   Weight of the case, the test, textual explanation.

   For a test, use one a testNArg function,
   e.g. test1Arg, test2Arg, etc.
   where N stands for the number of arguments the
   function being tested takes.
*)

let testCases = [
    (1, test1Arg Solution.q1 Student.q1 0, "q1 0");
    (1, test2Arg Solution.q2 Student.q2 5 3, "q2 5 3");
    (1, test1Arg Solution.q3 Student.q3 (fun n -> n), "q3 (fun n -> n)");
    (1, test2Arg Solution.q4 Student.q4 (fun n -> n) 0, "q4 (fun n -> n) 0");
    ]

