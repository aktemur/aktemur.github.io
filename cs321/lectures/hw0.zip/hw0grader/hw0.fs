module Student

let q1 z = failwith "Not implemented yet."

let q2 n m = failwith "Not implemented yet."

let q3 f = failwith "Not implemented yet."

let q4 f n = failwith "Not implemented yet."

let q5 t = failwith "Not implemented yet."

let q6 p1 p2 = failwith "Not implemented yet."

