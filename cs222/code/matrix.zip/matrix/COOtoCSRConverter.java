package matrix;

public class COOtoCSRConverter {
    private COOMatrix cooMatrix;
    private CSRMatrix csrMatrix;
    
    public COOtoCSRConverter(COOMatrix matrix) {
        cooMatrix = matrix;
        matrix.normalize();
        csrMatrix = new CSRMatrix(cooMatrix.getNumRows(), cooMatrix.getNumCols(), cooMatrix.getNumElements());
        setCSRValues();
        setCSRColumnIndices();
        setCSRRowIndices();
    }


    private void setCSRValues() {
        double[] vals = new double[cooMatrix.getNumElements()];        
        for (int i = 0; i < vals.length; i++) {
            vals[i] = cooMatrix.getElements().get(i).value;
        }
        csrMatrix.setVals(vals);
    }

    private void setCSRColumnIndices() {
        int[] cols = new int[cooMatrix.getNumElements()];
        for (int i = 0; i < cols.length; i++) {
            cols[i] = cooMatrix.getElements().get(i).colIndex;
        }
        csrMatrix.setCols(cols);
    }

    private void setCSRRowIndices() {
        int[] rows = new int[cooMatrix.getNumRows() + 1];
        // set rows[i+1] to contain # of elements in row i
        for (int i = 0; i < cooMatrix.getNumElements(); i++) {
            int rowIndex = cooMatrix.getElements().get(i).rowIndex; 
            rows[rowIndex + 1] += 1;
        }

        // Accumulate values in the rows array
        for (int i = 1; i < rows.length; i++) {
            rows[i] += rows[i - 1];
        }
        
        csrMatrix.setRows(rows);
    }
    
    public CSRMatrix getCSRMatrix() {
        return csrMatrix;
    }

}
