package matrix;

public class COOElement implements Comparable<COOElement> {
    int rowIndex;
    int colIndex;
    double value;

    COOElement(int rowIndex, int colIndex, double value) {
        this.rowIndex = rowIndex;
        this.colIndex = colIndex;
        this.value = value;
    }

    @Override
    // Comparison according to the row-major order
    public int compareTo(COOElement other) {
        if (this.rowIndex < other.rowIndex) {
            return -1;
        } else if (this.rowIndex > other.rowIndex) {
            return 1;
        } else if (this.colIndex < other.colIndex) {
            return -1;          
        } else if (this.colIndex > other.colIndex) {
            return 1;
        } else {
            return 0;
        }
    }
}
