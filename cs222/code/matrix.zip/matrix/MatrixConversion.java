package matrix;

import java.io.IOException;
import java.util.Scanner;

public class MatrixConversion {
    public static void main(String[] args) throws IOException {
        String fileName = getFileNameFromUser();
        MatrixMarketReader reader = new MatrixMarketReader(fileName);
        COOMatrix cooMatrix = reader.getCOOMatrix();
        COOtoCSRConverter converter = new COOtoCSRConverter(cooMatrix);
        CSRMatrix csrMatrix = converter.getCSRMatrix();
        System.out.println(csrMatrix);
    }

    public static String getFileNameFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the Matrix Market file name: ");
        String line = scanner.nextLine();
        scanner.close();
        return line;
    }
}
