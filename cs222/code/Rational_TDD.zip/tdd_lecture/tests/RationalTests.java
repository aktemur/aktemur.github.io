package tdd_lecture.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import tdd_lecture.Rational;

public class RationalTests {

    @Test
    public void testZeroArgumentCtor() {
        Rational r = new Rational();
        assertEquals(0, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }
    
    @Test
    public void testOneArgumentCtor1() {
        Rational r = new Rational(42);
        assertEquals(42, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }
    
    @Test
    public void testOneArgumentCtor2() {
        Rational r = new Rational(0);
        assertEquals(0, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }
    
    @Test
    public void testOneArgumentCtor3() {
        Rational r = new Rational(-17);
        assertEquals(-17, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor0() {
        Rational r = new Rational(0, 5);
        assertEquals(0, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor1() {
        Rational r = new Rational(2, 5);
        assertEquals(2, r.getNumerator());
        assertEquals(5, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor2() {
        Rational r = new Rational(4, 10);
        assertEquals(2, r.getNumerator());
        assertEquals(5, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor3() {
        Rational r = new Rational(10, 3);
        assertEquals(10, r.getNumerator());
        assertEquals(3, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor4() {
        Rational r = new Rational(10, 4);
        assertEquals(5, r.getNumerator());
        assertEquals(2, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor5() {
        Rational r = new Rational(5, -3);
        assertEquals(-5, r.getNumerator());
        assertEquals(3, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor6() {
        Rational r = new Rational(-5, 3);
        assertEquals(-5, r.getNumerator());
        assertEquals(3, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor7() {
        Rational r = new Rational(-5, -3);
        assertEquals(5, r.getNumerator());
        assertEquals(3, r.getDenominator());        
    }


    @Test
    public void testTwoArgumentCtor8() {
        Rational r = new Rational(5, 5);
        assertEquals(1, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor9() {
        Rational r = new Rational(10, 2);
        assertEquals(5, r.getNumerator());
        assertEquals(1, r.getDenominator());        
    }

    @Test
    public void testTwoArgumentCtor10() {
        Rational r = new Rational(48, 36);
        assertEquals(4, r.getNumerator());
        assertEquals(3, r.getDenominator());        
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void testTwoArgumentCtor11() {
        Rational r = new Rational(5, 0);
    }
    
    @Test
    public void testGCD() {
        assertEquals(1, Rational.gcd(1, 1));
        assertEquals(2, Rational.gcd(2, 4));
        assertEquals(1, Rational.gcd(5, 7));
        assertEquals(5, Rational.gcd(10, 15));
        assertEquals(5, Rational.gcd(20, 15));
        assertEquals(15, Rational.gcd(45, 15));
    }
    
    @Test
    public void testAdd1() {
        Rational r1 = new Rational(2, 5);
        Rational r2 = new Rational(2, 5);
        Rational result = r1.add(r2); 
        assertEquals(4, result.getNumerator());
        assertEquals(5, result.getDenominator());        
    }

    @Test
    public void testAdd2() {
        Rational r1 = new Rational(2, 7);
        Rational r2 = new Rational(2, 5);
        Rational result = r1.add(r2); 
        assertEquals(24, result.getNumerator());
        assertEquals(35, result.getDenominator());        
    }

    @Test
    public void testAdd3() {
        Rational r1 = new Rational(2, 10);
        Rational r2 = new Rational(3, 5);
        Rational result = r1.add(r2); 
        assertEquals(4, result.getNumerator());
        assertEquals(5, result.getDenominator());        
    }
    
    @Test
    public void testAdd4() {
        Rational r1 = new Rational(-4, 10);
        Rational r2 = new Rational(2, 5);
        Rational result = r1.add(r2); 
        assertEquals(0, result.getNumerator());
        assertEquals(1, result.getDenominator());        
    }

    @Test
    public void testAdd5() {
        Rational r1 = new Rational(2, -5);
        Rational r2 = new Rational(2, 4);
        Rational result = r1.add(r2); 
        assertEquals(1, result.getNumerator());
        assertEquals(10, result.getDenominator());        
    }

    @Test
    public void testAdd6() {
        Rational r1 = new Rational(0, 5);
        Rational r2 = new Rational(2, 4);
        Rational result = r1.add(r2); 
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());        
    }

    @Test
    public void testAdd7() {
        Rational r1 = new Rational(2, -5);
        Rational r2 = new Rational(-2, 4);
        Rational result = r1.add(r2); 
        assertEquals(-9, result.getNumerator());
        assertEquals(10, result.getDenominator());        
    }
    
    @Test(expected=ArithmeticException.class)
    public void testDiv() {
        Rational r1 = new Rational(2, 3);
        Rational r2 = new Rational(0);
        Rational result = r1.divide(r2); 
    }

    // And you write test cases for 
    // division, multiplication and subtraction as well...
}
