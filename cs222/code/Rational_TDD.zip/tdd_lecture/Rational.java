package tdd_lecture;

public class Rational {
    private int numerator;
    private int denominator;
    
    public Rational () {
        this(0);
    }
    
    public Rational(int n) {
        this(n, 1);
    }
    
    public Rational(int n, int m) {
        if (m == 0) 
            throw new IllegalArgumentException("Don't gimme zero denominator dude.");
        numerator = n;
        denominator = m;
        normalize();
    }

    private void normalize() {
        if (denominator < 0) {
            numerator *= -1;
            denominator *= -1;
        }
        int divisor = gcd(numerator, denominator); 
        numerator /= divisor;
        denominator /= divisor;
    }
    
    public static int gcd(int number1, int number2) {
        int r = number1 % number2;
        while (r != 0) {
            number1 = number2;
            number2 = r;
            r = number1 % number2;
        }
        return number2;
    }

    public Rational add(Rational other) {
        return new Rational(numerator * other.getDenominator() + denominator * other.getNumerator(),
                denominator * other.getDenominator());
    }
    
    public Rational subtract(Rational other) {
        return null;
    }
    
    public Rational multiply(Rational other) {
        return null;
    }
    
    public Rational divide(Rational other) {
        if (other.getNumerator() == 0) {
            throw new ArithmeticException("Div by zero");
        }
        return new Rational(numerator * other.getDenominator(), denominator * other.getNumerator());
    }
    
    public int getNumerator() {
        return numerator;
    }
    
    public int getDenominator() {
        return denominator;
    }
}
