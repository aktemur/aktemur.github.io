package refactoringGeneratePrimes.v3;

/// This class Generates prime numbers up to a user specified
/// maximum. The algorithm used is the Sieve of Eratosthenes. 
///
/// Eratosthenes of Cyrene, b. c. 276 BC, Cyrene, Libya --
/// d. c. 194, Alexandria. The first man to calculate the
/// circumference of the Earth. Also known for working on
/// calendars with leap years and ran the library at
/// Alexandria. 
///
/// The algorithm is quite simple. Given an array of integers
/// starting at 2. Cross out all multiples of 2. Find the
/// next uncrossed integer, and cross out all of its multiples.
/// Repeat until you have passed the square root of the
/// maximum value. 
///
/// Written by Robert C. Martin on 9 Dec 1999

public class PrimeGenerator {
	private static boolean[] crossedOut;

	public static int[] generatePrimeNumbers(int maxValue) {
		if (maxValue < 2)
			return new int[0]; // return null array if bad input.
		else {	
			uncrossIntegersUpTo(maxValue);
			crossOutMultiples();
			return getUncrossedIntegers();
		}	
	}
	private static int[] getUncrossedIntegers() {
		int[] result = new int[getNumberOfUncrossedNumbers()];

		// move the primes into the result
		for (int i = 0, j = 0; i < crossedOut.length; i++) {
			if (!crossedOut[i]) // if prime
				result[j++] = i;
		}
		return result;
	}

	private static int getNumberOfUncrossedNumbers() {
		// how many primes are there?
		int count = 0;
		for (int i = 0; i < crossedOut.length; i++) {
			if (!crossedOut[i])
				count++; // bump count.
		}
		return count;
	}
	private static void crossOutMultiples() {
		for (int i = 2; i < getPrimeNumberLimit(); i++) {
			if (!crossedOut[i]) // if i is uncrossed, cross its multiples.
			{
				crossOutMultiplesOf(i);
			}
		}
	}
	private static double getPrimeNumberLimit() {
		return Math.sqrt(crossedOut.length) + 1;
	}
	private static void crossOutMultiplesOf(int i) {
		for (int multiple = 2 * i; multiple < crossedOut.length; multiple += i)
			crossedOut[multiple] = true; // multiple is not prime
	}
	
	private static void uncrossIntegersUpTo(int maxValue) {
		crossedOut = new boolean[maxValue + 1];
		crossedOut[0] = crossedOut[1] = true;
		for (int i = 2; i < crossedOut.length; i++)
			crossedOut[i] = false;
	}

	public static void main(String[] args) {
		for(int i : generatePrimeNumbers(400)) {
			System.out.print(i + " ");
		}
	}
}
