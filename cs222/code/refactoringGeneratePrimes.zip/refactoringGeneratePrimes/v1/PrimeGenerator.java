package refactoringGeneratePrimes.v1;

/// This class Generates prime numbers up to a user specified
/// maximum. The algorithm used is the Sieve of Eratosthenes. 
///
/// Eratosthenes of Cyrene, b. c. 276 BC, Cyrene, Libya --
/// d. c. 194, Alexandria. The first man to calculate the
/// circumference of the Earth. Also known for working on
/// calendars with leap years and ran the library at
/// Alexandria. 
///
/// The algorithm is quite simple. Given an array of integers
/// starting at 2. Cross out all multiples of 2. Find the
/// next uncrossed integer, and cross out all of its multiples.
/// Repeat until you have passed the square root of the
/// maximum value. 
///
/// Written by Robert C. Martin on 9 Dec 1999

public class PrimeGenerator {
	private static int s;
	private static boolean[] fs;
	private static int[] primes;
	public static int[] generatePrimeNumbers(int maxValue) {
		if (maxValue < 2) 
			return new int[0]; 
		else {
			initializeSieve(maxValue);
			sieve();
			loadPrimes();

			return primes; // return the primes
		}
	}
	private static void loadPrimes() {
		int i;
		int j;
		// how many primes are there?
		int count = 0;
		for (i = 0; i < s; i++) {
			if (fs[i])
				count++; // bump count.
		}

		primes = new int[count];

		// move the primes into the result
		for (i = 0, j = 0; i < s; i++) {
			if (fs[i]) // if prime
				primes[j++] = i;
		}
	}
	private static void sieve() {
		int i;
		// sieve
		int j;
		for (i = 2; i < Math.sqrt(s) + 1; i++) {
			if (fs[i]) // if i is uncrossed, cross its multiples.
			{
				for (j = 2 * i; j < s; j += i)
					fs[j] = false; // multiple is not prime
			}
		}
	}
	private static void initializeSieve(int maxValue) {
		s = maxValue + 1;
		fs = new boolean[s];
		int i;

		// initialize array to true.
		for (i = 0; i < s; i++)
			fs[i] = true;

		// get rid of known non-primes
		fs[0] = fs[1] = false;
	}
	public static void main(String[] args) {
		for(int i : generatePrimeNumbers(400)) {
			System.out.print(i + " ");
		}
	}
}
