package tdd;

public class Rational {
    private int numerator;
    private int denominator;
    
    public Rational(int n, int d) {
        if (d == 0) {
            throw new IllegalArgumentException("Denominator cannot be zero.");
        }
        numerator = n;
        denominator = d;
        normalize();
    }

    public Rational(int n) {
        this(n, 1);
    }
    
    public Rational() {
        this(0);
    }

    private void normalize() {
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
        int gcd = gcd(numerator, denominator);
        numerator = numerator / gcd;
        denominator = denominator / gcd;
    }
    
    public int getNumerator() {
        return numerator;
    }
    
    public int getDenominator() {
        return denominator;
    }
    
    private static int gcd(int x, int y) {
        int r = x % y;
        while (r != 0) {
            x = y;
            y = r;
            r = x % y;
        }
        return y;
    }

    public Rational add(Rational that) {
        return new Rational(this.numerator*that.denominator + this.denominator*that.numerator, 
                this.denominator*that.denominator);
    }
}
