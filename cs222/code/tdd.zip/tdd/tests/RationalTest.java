package tdd.tests;

import static org.junit.Assert.*;
import org.junit.Test;
import tdd.Rational;

public class RationalTest {

    @Test
    public void testTwoArgumentConstructor() {
        Rational rational = new Rational(3, 5);
        assertEquals(3, rational.getNumerator());
        assertEquals(5, rational.getDenominator());
    }

    @Test
    public void testOneArgumentConstructor() {
        Rational rational = new Rational(3);
        assertEquals(3, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }

    @Test
    public void testZeroArgumentConstructor() {
        Rational rational = new Rational();
        assertEquals(0, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }

    @Test(expected=IllegalArgumentException.class)
    public void testTwoArgumentConstructorIllegalDenominator() {
        Rational rational = new Rational(3, 0);
    }

    @Test
    public void testNormalization1() {
        Rational rational = new Rational(10, 15);
        assertEquals(2, rational.getNumerator());
        assertEquals(3, rational.getDenominator());
    }
    
    @Test
    public void testNormalization2() {
        Rational rational = new Rational(20, 10);
        assertEquals(2, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }
    
    @Test
    public void testNormalization3() {
        Rational rational = new Rational(17, 17);
        assertEquals(1, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }
    
    @Test
    public void testNormalization4() {
        Rational rational = new Rational(-7, 5);
        assertEquals(-7, rational.getNumerator());
        assertEquals(5, rational.getDenominator());
    }

    @Test
    public void testNormalization5() {
        Rational rational = new Rational(7, -5);
        assertEquals(-7, rational.getNumerator());
        assertEquals(5, rational.getDenominator());
    }

    @Test
    public void testNormalization6() {
        Rational rational = new Rational(-7, -5);
        assertEquals(7, rational.getNumerator());
        assertEquals(5, rational.getDenominator());
    }

    @Test
    public void testNormalization7() {
        Rational rational = new Rational(-10, 15);
        assertEquals(-2, rational.getNumerator());
        assertEquals(3, rational.getDenominator());
    }
    
    @Test
    public void testNormalization8() {
        Rational rational = new Rational(20, -10);
        assertEquals(-2, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }
    
    @Test
    public void testNormalization9() {
        Rational rational = new Rational(-17, -17);
        assertEquals(1, rational.getNumerator());
        assertEquals(1, rational.getDenominator());
    }
    
    @Test
    public void testAddition1() {
        Rational rational1 = new Rational(2, 3);
        Rational rational2 = new Rational(5, 3);
        Rational sum = rational1.add(rational2);
        
        assertEquals(7, sum.getNumerator());
        assertEquals(3, sum.getDenominator());
    }

    @Test
    public void testAddition2() {
        Rational rational1 = new Rational(2, 3);
        Rational rational2 = new Rational(4, 3);
        Rational sum = rational1.add(rational2);
        
        assertEquals(2, sum.getNumerator());
        assertEquals(1, sum.getDenominator());
    }
    
    @Test
    public void testAddition3() {
        Rational rational1 = new Rational(2, 3);
        Rational rational2 = new Rational(7, 5);
        Rational sum = rational1.add(rational2);
        
        assertEquals(31, sum.getNumerator());
        assertEquals(15, sum.getDenominator());
    }

    @Test
    public void testAddition4() {
        Rational rational1 = new Rational(-7, 5);
        Rational rational2 = new Rational(7, 5);
        Rational sum = rational1.add(rational2);
        
        assertEquals(0, sum.getNumerator());
        assertEquals(1, sum.getDenominator());
    }
}

















