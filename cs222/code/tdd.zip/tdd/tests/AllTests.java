package tdd.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/*
 * author: Atom Karinca
 */

@RunWith(Suite.class)
@SuiteClasses({ ClockTest.class, RationalTest.class })
public class AllTests {

}
