package tdd.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import tdd.Clock;

/*
 * author: Atom Karinca
 */

public class ClockTest {

    @Test
    public void testClock() {
        Clock c = new Clock(0,0,0);
        assertEquals(0, c.getHour());
        assertEquals(0, c.getMinute());
        assertEquals(0, c.getSecond());
    }

    @Test
    public void testClock2() {
        Clock c = new Clock(12,45,23);
        assertEquals(12, c.getHour());
        assertEquals(45, c.getMinute());
        assertEquals(23, c.getSecond());
    }

    @Test
    public void testClock3() {
        Clock c = new Clock(24,60,60);
        assertEquals(0, c.getHour());
        assertEquals(0, c.getMinute());
        assertEquals(0, c.getSecond());
    }

    @Test
    public void testToString() {
        Clock c = new Clock(0,0,0);
        assertEquals("00:00:00", c.toString());
    }

    @Test
    public void testToString2() {
        Clock c = new Clock(12,10,8);
        assertEquals("12:10:08", c.toString());
    }

    @Test
    public void testToString3() {
        Clock c = new Clock(2,0,56);
        assertEquals("02:00:56", c.toString());
    }

}
