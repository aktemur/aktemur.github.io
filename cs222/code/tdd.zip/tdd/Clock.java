package tdd;

/*
 * author: Atom Karinca
 */

public class Clock {
    private int hour;
    private int minute;
    private int second;
    
    public Clock(int h, int m, int s) {
        if(h < 0 || h >= 24)
            h = 0;
        if(m < 0 || m >= 60)
            m = 0;
        if(s < 0 || s >= 60)
            s = 0;
        hour = h;
        minute = m;
        second = s;
    }
    
    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getSecond() {
        return second;
    }

    public String toString() {
        return String.format("%02d:%02d:%02d", hour, minute, second);
    }
}
