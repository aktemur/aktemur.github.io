package refactoringMovieStore.end;

public class Movie {
    private String title;
    private MovieKind kind;

    public Movie(String title, MovieKind kind) {
       this.title = title;
       this.kind = kind;
    }

    public double getPrice(int numDaysRented) {
        return kind.getPrice(numDaysRented);
    }

    public int getFrequentRenterPoints(int numDaysRented) {
        return kind.getPoints(numDaysRented);
    }

    public String getTitle() {
       return title;
    }
    
    public void setKind(MovieKind kind) {
        this.kind = kind;
    }
}

abstract class MovieKind {
    public static MovieKind REGULAR = new Regular();
    public static MovieKind CHILDRENS = new Childrens();
    public static MovieKind NEW_RELEASE = new NewRelease();
    
    public int getPoints(int numDaysRented) {
        return 1;
    }
    
    public abstract double getPrice(int numDaysRented);
}

class Childrens extends MovieKind {
    @Override
    public double getPrice(int numDaysRented) {
        double price = 1.5;
        if (numDaysRented > 3)
           price += (numDaysRented - 3) * 1.5;
        return price;
    }    
}

class Regular extends MovieKind {
    @Override
    public double getPrice(int numDaysRented) {
        double price = 2;
        if (numDaysRented > 2)
           price += (numDaysRented - 2) * 1.5;
        return price;
    }
    
}

class NewRelease extends MovieKind {
    @Override
    public double getPrice(int numDaysRented) {
        return numDaysRented * 3;        
    }
    
    @Override
    public int getPoints(int numDaysRented) {
        if(numDaysRented > 1) {
            return 2;
        } else {
            return 1;            
        }
    }
}
