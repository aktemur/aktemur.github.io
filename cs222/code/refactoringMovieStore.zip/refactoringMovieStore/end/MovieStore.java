package refactoringMovieStore.end;

public class MovieStore {
    public static void main(String[] args) {
        Customer cust = new Customer("Ahmet");
        Movie movSevenSamurai = new Movie("Seven Samurai", MovieKind.REGULAR);
        Movie movCorpseBride = new Movie("Corpse Bride", MovieKind.CHILDRENS);
        Movie movInception = new Movie("Inception", MovieKind.NEW_RELEASE);
        Rental rentS = new Rental(movSevenSamurai, 3);
        Rental rentC = new Rental(movCorpseBride, 2);
        Rental rentI = new Rental(movInception, 5);

        System.out.println("Movie Title : " + movSevenSamurai.getTitle());
        System.out.println("Rental Time : " + rentS.getDaysRented());

        System.out.println("Movie Title : " + movCorpseBride.getTitle());
        System.out.println("Rental Time : " + rentC.getDaysRented());

        System.out.println("Movie Title : " + movInception.getTitle());
        System.out.println("Rental Time : " + rentI.getDaysRented());

        System.out.println("----------------------------");
        cust.addRental(rentS);
        System.out.println(cust.getReceipt());
        System.out.println("----------------------------");
        cust.addRental(rentC);
        System.out.println(cust.getReceipt());
        System.out.println("----------------------------");
        cust.addRental(rentI);
        System.out.println(cust.getReceipt());
        System.out.println("----------------------------");
        
        // Changing the kind of a Movie is easy.
        movInception.setKind(MovieKind.REGULAR);
        System.out.println(cust.getReceipt());

    }
}
