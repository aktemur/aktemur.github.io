package refactoringMovieStore.original;

import java.util.Enumeration;
import java.util.Vector;

class Movie {

   public static final int CHILDRENS = 2;
   public static final int REGULAR = 0;
   public static final int NEW_RELEASE = 1;

   private String _title;
   private int _priceCode;

   public Movie(String title, int priceCode) {
      _title = title;
      _priceCode = priceCode;
   }

   public int getPriceCode() {
      return _priceCode;
   }

   public void setPriceCode(int arg) {
      _priceCode = arg;
   }

   public String getTitle() {
      return _title;
   }
}

class Rental {
   private Movie _movie;
   private int _daysRented;

   public Rental(Movie movie, int daysRented) {
      _movie = movie;
      _daysRented = daysRented;
   }

   public int getDaysRented() {
      return _daysRented;
   }

   public Movie getMovie() {
      return _movie;
   }
}

class Customer {
   private String _name;
   private Vector<Rental> _rentals = new Vector<Rental>();

   public Customer(String name) {
      _name = name;
   }

   public void addRental(Rental arg) {
      _rentals.addElement(arg);
   }

   public String getName() {
      return _name;
   }

   public String statement() {
      double totalAmount = 0;
      int frequentRenterPoints = 0;
      Enumeration<Rental> rentals = _rentals.elements();
      String result = "Rental Record for " + getName() + "\n";
      while (rentals.hasMoreElements()) {
         Rental each = rentals.nextElement();

         double thisAmount = 0;
         // determine amounts for each line
         switch (each.getMovie().getPriceCode()) {
         case Movie.REGULAR:
            thisAmount += 2;
            if (each.getDaysRented() > 2)
               thisAmount += (each.getDaysRented() - 2) * 1.5;
            break;
         case Movie.NEW_RELEASE:
            thisAmount += each.getDaysRented() * 3;
            break;
         case Movie.CHILDRENS:
            thisAmount += 1.5;
            if (each.getDaysRented() > 3)
               thisAmount += (each.getDaysRented() - 3) * 1.5;
            break;

         }

         // add frequent renter points
         frequentRenterPoints++;
         // add bonus for a two day new release rental
         if ((each.getMovie().getPriceCode() == Movie.NEW_RELEASE)
               && each.getDaysRented() > 1)
            frequentRenterPoints++;

         // show figures for this rental
         result += "\t" + each.getMovie().getTitle() + "\t"
               + String.valueOf(thisAmount) + "\n";
         totalAmount += thisAmount;

      }
      // add footer lines
      result += "Amount owed is " + String.valueOf(totalAmount) + "\n";
      result += "You earned " + String.valueOf(frequentRenterPoints)
            + " frequent renter points";
      return result;

   }
}

public class MovieStore {
   public static void main(String[] args) {
      Customer cust = new Customer("Ahmet");
      Movie movSevenSamurai = new Movie("Seven Samurai", 0);
      Movie movCorpseBride = new Movie("Corpse Bride", 2);
      Movie movInception = new Movie("Inception", 1);
      Rental rentS = new Rental(movSevenSamurai, 3);
      Rental rentC = new Rental(movCorpseBride, 2);
      Rental rentI = new Rental(movInception, 5);

      System.out.println("Movie Title : " + movSevenSamurai.getTitle());
      System.out.println("Rental Time : " + rentS.getDaysRented());

      System.out.println("Movie Title : " + movCorpseBride.getTitle());
      System.out.println("Rental Time : " + rentC.getDaysRented());

      System.out.println("Movie Title : " + movInception.getTitle());
      System.out.println("Rental Time : " + rentI.getDaysRented());

      cust.addRental(rentS);
      System.out.println(cust.statement());
      cust.addRental(rentC);
      System.out.println(cust.statement());
      cust.addRental(rentI);
      System.out.println(cust.statement());
   }
}

/*
 * abstract class Price { abstract int getPriceCode(); }
 * 
 * class ChildrensPrice extends Price { int getPriceCode() { return
 * Movie.CHILDRENS; } }
 * 
 * class NewReleasePrice extends Price { int getPriceCode() { return
 * Movie.NEW_RELEASE; } }
 * 
 * class RegularPrice extends Price { int getPriceCode() { return Movie.REGULAR;
 * } }
 */