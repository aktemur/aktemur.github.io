package concurrency;

/*
 * author: Atom Karinca
 */

class Adder extends Thread {    
    public static final int NUM_ITERS = 20000;
    public static final int LENGTH = 1000000;
    public int beginIndex;
    public double sum = 0;
    
    public Adder(int begin) {
        beginIndex = begin;
    }
    
    public void sum() {
        for(int j = 0; j < NUM_ITERS; j++) {
            sum = 0;
            for(int i = beginIndex; i < beginIndex + LENGTH/4; i++) {
                sum = sum + 0.001;
            }
        }
    }

    public void run() {
        sum();
    }    
}

public class SumInParallel {
    public static void main(String[] args) throws InterruptedException {        
        Adder adder1 = new Adder(0);
        Adder adder2 = new Adder(Adder.LENGTH/4);
        Adder adder3 = new Adder(2*Adder.LENGTH/4);
        Adder adder4 = new Adder(3*Adder.LENGTH/4);
        
        long time1 = System.currentTimeMillis();
        adder1.start();
        adder2.start();
        adder3.start();
        adder4.start();
        
        // wait for the threads to finish
        adder1.join();
        adder2.join();
        adder3.join();
        adder4.join();
        long time2 = System.currentTimeMillis();
        double sum = adder1.sum + adder2.sum + adder3.sum + adder4.sum;
        System.out.println("Sum: " + sum);
        System.out.println("Time taken: " + (time2 - time1) / 1000);
    }
}
