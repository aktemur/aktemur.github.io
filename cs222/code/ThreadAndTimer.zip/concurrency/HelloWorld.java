package concurrency;
/*
 * HelloWorld.java
 *
 * Created on January 5, 2006, 6:12 PM
 *
 * From "Multiprocessor Synchronization and Concurrent Data Structures",
 * by Maurice Herlihy and Nir Shavit.
 * Copyright 2006 Elsevier Inc. All rights reserved.
 */

/* A thread is a program that runs in parallel to the current 
 * execution. To create a thread, extend the Thread class, override 
 * its run() method. Then instantiate the class and invoke its start()
 * method.
 */
class HelloThread extends Thread {
    public String message;
    
    public HelloThread(String s) {
        message = s;
    }
    
    public void run() {
        System.out.println(message);
    }    
}

public class HelloWorld {
    public static void main(String[] args) throws InterruptedException {
        Thread[] thread = new Thread[8];
        // create thread objects
        for (int i = 0; i < thread.length; i++) {
            String message = "Hello world from thread " + i;
            thread[i] = new HelloThread(message);
        }
        // start threads
        for (int i = 0; i < thread.length; i++) {
            thread[i].start();
        }
        // wait for them to finish
        // What happens if you omit this part?
        for (int i = 0; i < thread.length; i++) {
            thread[i].join();
        }
        System.out.println("done!");
    }
}
