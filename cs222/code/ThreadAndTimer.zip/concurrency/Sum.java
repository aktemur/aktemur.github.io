package concurrency;

/*
 * author: Atom Karinca
 */

public class Sum {
    public static final int NUM_ITERS = 20000;
    public static final int LENGTH = 1000000;
    public static double sum = 0;
    
    public static void main(String[] args) {        
        long time1 = System.currentTimeMillis();
        sum();        
        long time2 = System.currentTimeMillis();
        System.out.println("Sum: " + sum);
        System.out.println("Time taken: " + (time2 - time1) / 1000);
    }
    
    public static void sum() {
        for(int j = 0; j < NUM_ITERS; j++) {
            sum = 0;
            for(int i = 0; i < LENGTH; i++) {
                sum = sum + 0.001;
            }
        }
    }
}
