package concurrency;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * author: Atom Karinca
 */

class Flasher extends Thread {
    public void run() {
        while(true) {
            if(FlashingText.label.getText() == null) {
                FlashingText.label.setText("With great power comes great responsibility.");
            } else {
                FlashingText.label.setText(null);
            }
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                // Ignore the exception
            }
        }
    }
}

public class FlashingText {
    public static JLabel label = new JLabel();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Flashing text");
        frame.setSize(200, 200);
        frame.setLayout(new BorderLayout());
        frame.add(label);
        frame.add(new JButton("OK"), BorderLayout.SOUTH);
        frame.setVisible(true);
        new Flasher().start();
    }
}
