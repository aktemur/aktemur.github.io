package concurrency;

import java.util.concurrent.atomic.AtomicInteger;

/*
 * author: Atom Karinca
 */

/*
 * Run this program multiple times to see the output.
 * How does the result vary? Why does that happen?
 *
 */
class Racer extends Thread {    
    private static final int NUM_ITERS = 1000000;

    public void run() {
        for(int j = 0; j < NUM_ITERS; j++) {
            RaceCondition.sum();
        }
    }    
}

public class RaceCondition {
    public static long sum = 0;

    
    // What happens when you make this method "synchronized"?
    // Do you still see the bug?    
    //synchronized 
    public static void sum() {
        sum = sum + 1;
    }

    public static void main(String[] args) throws InterruptedException {        
        Racer left = new Racer();
        Racer right = new Racer();

        left.start();
        right.start();

        // wait for the threads to finish
        left.join();
        right.join();

        System.out.println("Sum: " + sum);
    }
}
