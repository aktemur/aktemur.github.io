package timer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.Timer;

/*
 * author: Atom Karinca
 */

public class TimerTest {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300, 300);
        frame.setVisible(true);
        Timer timer = new Timer(1000, new TimerHandler(frame));
        timer.start();
    }
}

class TimerHandler implements ActionListener {
    private JFrame frame;
    
    public TimerHandler(JFrame frame) {
        this.frame = frame;
    }
    
    public void actionPerformed(ActionEvent e) {        
        Random rand = new Random();
        int r = rand.nextInt(255);
        int g = rand.nextInt(255);
        int b = rand.nextInt(255);
        
        frame.setBackground(new Color(r, g, b));
    }
}
