package network.multipleClients;

import java.net.*;
import java.util.Scanner;

/**
 * Example Server program using TCP.
 */

public class Server {
    // server port number
    public final static int PORT = 3458;

    public static void main(String args[]) throws Exception {        
        // create socket and bind to port
        ServerSocket sock = new ServerSocket(PORT);
        System.out.println("Server is waiting for clients to connect.");

        while(true) {
            // Listen to new connection.
            Socket clientSocket = sock.accept();
            System.out.println("Client has connected.");
            // Create a thread that handles the client connection in parallel
            // so that the server is not blocked.
            // Then go back to the beginning of the loop to continue listening
            // to the new connections.
            new Thread(new ChatHandler(clientSocket)).start();
        }			
    }
}

class ChatHandler implements Runnable {
    private Socket clientSocket;

    public ChatHandler(Socket s) {
        clientSocket = s;
    }

    @Override
    public void run() {
        try {
            Scanner reader = new Scanner(clientSocket.getInputStream());
            while(true) {
                // read msg from client, and print to terminal.
                String msg = reader.nextLine();
                System.out.println(clientSocket.getInetAddress() + " > " + msg);
            }
        } catch(Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }    
}

