package network.simpleChat;

import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 * Example Client program using TCP.
 */

public class Client {
    public static void main(String args[]) throws Exception {
        Scanner userInput = new Scanner(System.in);
        System.out.print("Enter server IP:");
        String serverIP = userInput.nextLine();

        // When the socket object is created,
        // connection is made.
        Socket socket = new Socket(serverIP, Server.PORT);

        // create reader and writer
        PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
        Scanner reader = new Scanner(socket.getInputStream());
        System.out.println("Connected to Server");

        while(true) {
            System.out.print("Enter message to send: ");
            String message = userInput.nextLine();
            writer.println(message);

            // get data from the server
            System.out.print("Waiting for the server response...");
            String answer = reader.nextLine();
            System.out.println(" > " + answer);
        }
    }
}