package network.simpleChat;

import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 * Example Server program using TCP.
 */

public class Server {
    // server port number
    public final static int PORT = 3458;

    public static void main(String args[]) throws Exception {        
        // create socket and bind to port
        ServerSocket sock = new ServerSocket(PORT);

        System.out.println("Server is waiting for client to connect.");
        Socket clientSocket = sock.accept();
        System.out.println("Client has connected.");

        PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);
        Scanner reader = new Scanner(clientSocket.getInputStream());
        Scanner userInput = new Scanner(System.in);
        
        while(true) {
            // read msg from client
            System.out.println("Waiting for the client message...");
            String msg = reader.nextLine();
            System.out.println(clientSocket.getInetAddress() + " > " + msg);
            System.out.println("Enter message to send to the client: ");
            writer.println(userInput.nextLine());
        }			
    }
}