package network.simpleWebServer;

import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 * Example Web Server program using TCP.
 * 
 * Connect to this web server using your browser
 * at address
 * http://localhost:3458/ozyegin.edu.tr
 * http://localhost:3458/index.html
 * 
 */

public class Server {
    // server port number
    public final static int PORT = 3458;

    public static void main(String args[]) throws Exception {        
        // create socket and bind to port
        ServerSocket sock = new ServerSocket(PORT);

        while(true) {
            Socket clientSocket = sock.accept();
            System.out.println("Client " + clientSocket.getInetAddress() + " has connected.");

            DataOutputStream writer = new DataOutputStream(clientSocket.getOutputStream());
            Scanner reader = new Scanner(clientSocket.getInputStream());

            String firstLine = reader.nextLine(); 
            // Parse the first line to get the request data
            String url = firstLine.substring(5);
            url = url.substring(0, url.indexOf("HTTP/1.1"));
            System.out.println("URL is " + url + "\n");

            // Write the HTTP header for the response
            writer.writeBytes("HTTP/1.0 200 OK\r\n");
            writer.writeBytes("Connection: close\r\n");
            writer.writeBytes("Content-Type: text/html\r\n");
            writer.writeBytes("\r\n");        

            // Write the contents
            int random = (int)(Math.random() * 40);
            writer.writeBytes("<html><body>" + random + "<a href=\"http://");
            writer.writeBytes(url);
            writer.writeBytes("\">" + url + "</a></body></html>\n");

            // The end...
            writer.close();
            reader.close();
            clientSocket.close();
        }
    }
}