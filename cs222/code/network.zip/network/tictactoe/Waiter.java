package network.tictactoe;

/*
 * author: Atom Karinca
 */

public class Waiter implements Runnable {
    public TicTacToeGUI gui;
    
    public Waiter(TicTacToeGUI gui) {
        this.gui = gui;
    }
    
    @Override
    public void run() {
        int i = Networking.readInt();
        int j = Networking.readInt();
        System.out.println("Pressing on button " + i + ", " +j);
        gui.pressedOnButton(i, j);
    }
}

