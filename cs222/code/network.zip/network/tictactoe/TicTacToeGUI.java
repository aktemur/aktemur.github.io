package network.tictactoe;

import java.awt.GridLayout;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * author: Atom Karinca
 */

//The GUI is the view that contains buttons
public class TicTacToeGUI extends JPanel {
    private JFrame frame;
    private JButton[][] buttons = new JButton[3][3];
    private ButtonHandler[][] buttonHandlers = new ButtonHandler[3][3];
    private TicTacToeGrid grid;

    public TicTacToeGUI(JFrame frame) {
        this.frame = frame;
        grid = new TicTacToeGrid();

        setLayout(new GridLayout(3,3));
        setTitle(grid.getCurrentPlayer());

        for(int i = 0; i < buttons.length; i++) {
            for(int j = 0; j < buttons[0].length; j++) {
                buttons[i][j] = new JButton();
                add(buttons[i][j]);
                buttonHandlers[i][j] = new ButtonHandler(this, i, j);
                buttons[i][j].addActionListener(buttonHandlers[i][j]);
            }
        }
    }
    
    public void waitForOpponent() {
        // Create a thread that will run in parallel.
        // The thread will wait on the socket to 
        // receive data from the opponent.
        new Thread(new Waiter(this)).start();
    }

    public void pressedOnButton(int x, int y) {
        int player = grid.getCurrentPlayer();
        grid.markCellAndChangeTurn(x, y);
        buttons[x][y].removeActionListener(buttonHandlers[x][y]);
        buttons[x][y].setText(player + "");
        if(grid.hasWinningCondition()) {
            JOptionPane.showMessageDialog(null, "Player " + player + " has won!!!");
            System.exit(0);
        } else if(grid.hasTieCondition()) {
            JOptionPane.showMessageDialog(null, "Game tied!!!");
            System.exit(0);
        }
        setTitle(grid.getCurrentPlayer());        
    }

    public boolean canPlay() {
        return (Networking.IS_SERVER && grid.getCurrentPlayer() == 2) ||
               (!Networking.IS_SERVER && grid.getCurrentPlayer() == 1);
    }

    public void setTitle(int player) {
        if(Networking.IS_SERVER)
            frame.setTitle(player == 2 ? "Play..." : "Wait...");
        else
            frame.setTitle(player == 1 ? "Play..." : "Wait...");
    }
}

