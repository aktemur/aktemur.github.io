package network.tictactoe;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/*
 * author: Atom Karinca
 */

public class ButtonHandler implements ActionListener {
    private TicTacToeGUI gui;
    private int x, y;

    public ButtonHandler(TicTacToeGUI gui, int x, int y) {
        this.gui = gui;
        this.x = x;
        this.y = y;
    }

    public void actionPerformed(ActionEvent event) {
        JButton button = (JButton)event.getSource();

        if(gui.canPlay()) { // is it my turn?    
            button.removeActionListener(this);
            gui.pressedOnButton(x, y);
            System.out.println("Writing " + x + ", " + y);
            Networking.writeInt(x);
            Networking.writeInt(y);
            gui.waitForOpponent();
        }
    }
}
