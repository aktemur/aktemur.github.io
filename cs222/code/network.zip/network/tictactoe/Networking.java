package network.tictactoe;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/*
 * author: Atom Karinca
 */

public class Networking {
    public static boolean IS_SERVER = true;
    private static final int PORT = 8888; 
    private static DataOutputStream writer;
    private static DataInputStream reader;

    public static void setup() {
        try{            
            Scanner scanner = new Scanner(System.in);
            System.out.print("Is this the server (y/n)? ");        
            Networking.IS_SERVER = scanner.nextLine().equals("y");

            Socket socket;        
            if(IS_SERVER) {
                // create socket and bind to port
                ServerSocket serverSocket = new ServerSocket(PORT);

                System.out.println("Server is waiting for client to connect.");
                socket = serverSocket.accept();
                System.out.println("Client has connected.");
            } else {
                System.out.print("What's the server IP? ");
                String serverIP = scanner.nextLine();
                socket = new Socket(serverIP, PORT);
                System.out.println("Connected to server.");
            }

            writer = new DataOutputStream(socket.getOutputStream());
            reader = new DataInputStream(socket.getInputStream());
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        }        
    }

    public static int readInt() {
        try {
            return reader.readInt();
        } catch(IOException e) {
            throw new Error("IO Exception occurred.");
        }
    }

    public static void writeInt(int i) {
        try {
            writer.writeInt(i);
        } catch(IOException e) {
            throw new Error("IO Exception occurred.");
        }
    }   
}
