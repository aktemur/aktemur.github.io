package network.tictactoe;

import javax.swing.JFrame;


/**
 * A version of the TicTacToe game that can be played over
 * the network.
 * 
 */

public class TicTacToe {    
    public static void main(String[] args) {
        // First, set up the connections.       
        Networking.setup();
        
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,300);
        TicTacToeGUI gui = new TicTacToeGUI(frame);
        frame.add(gui);
        frame.setVisible(true);
        
        // Server is player 2, client is player 1.
        // Client plays the first, server should initially wait.
        if(Networking.IS_SERVER)
            gui.waitForOpponent();
    }
}
