import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class spiral extends PApplet {

public void setup() {
  background(255);
  smooth();
  noStroke();
  fill(0);
}

float radius = 1;
float theta = 0;

public void draw() {  
  float x = width/2 + radius * cos(theta);
  float y = height/2 + radius * sin(theta);
    
  ellipse(x, y, 5, 5);
    
  theta = theta + 0.05f;
  radius = radius + 0.1f;
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "spiral" });
  }
}
