import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class collision_hw extends PApplet {

float x1 = 20;
float y1 = 20;
float x2 = 380;
float y2 = 380;
float dx1 = 2;
float dy1 = 2;
float dx2 = -3;
float dy2 = -3;

public void setup() {
  size(400, 400);
  smooth();
}

public void draw() {
  background(255);
  fill(255,0,0);
  ellipse(x1, y1, 30, 30);
  fill(0,0,255);
  ellipse(x2, y2, 30, 30);
  x1 = x1 + dx1;
  x2 = x2 + dx2;
  y1 = y1 + dy1;
  y2 = y2 + dy2;
  
  if(x1 < 15) {
    dx1 = -dx1;
  }
  if(x2 > width-15) {
    dx2 = -dx2;
  }
  if(y1 < 15) {
    dy1 = -dy1;
  }
  if(y2 > width-15) {
    dy2 = -dy2;
  }
  if(dist(x1, y1, x2, y2) <= 30) {
    dx1 = -dx1;
    dx2 = -dx2;
    dy1 = -dy1;
    dy2 = -dy2;
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "collision_hw" });
  }
}
