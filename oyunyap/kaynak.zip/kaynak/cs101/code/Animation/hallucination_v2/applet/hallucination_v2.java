import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class hallucination_v2 extends PApplet {

public void setup() {
  background(255);
  smooth();
  noStroke();
  fill(0);
}

float startingTheta = 0;

public void draw() {
  background(255);
  float radius = 1;
  float theta = startingTheta;
  int n = 0;

  while(n < 1000) {
    float x = width/2 + radius * cos(theta);
    float y = height/2 + radius * sin(theta);

    ellipse(x, y, 5, 5);

    theta = theta + 0.05f;
    radius = radius + 0.1f;
    n = n + 1;
  }
  startingTheta = startingTheta + radians(10);
}


  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "hallucination_v2" });
  }
}
